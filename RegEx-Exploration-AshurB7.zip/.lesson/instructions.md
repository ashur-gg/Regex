## RegEx Practice  

Write the eleven regular expressions described below.  When finished, be sure to run the Output Test to ensure your expressions are working appropriately.  Upload the main.sh file to Canvas when you are finished.

**Note:**  For all the expressions, they will start with `^` and end with `$`

**The expected output is listed below these directions**
  
``` Bash
# Example
#  Write an egrep statement that matches any real number
echo matches any real number
egrep  '^[-+]?[0-9]*\.?[0-9]+$' textfile.txt

# 1. Modify the Regular Expression for a real number to "Require" a "+" or "-" at the beginning of the line.  "[-+]?[0-9]*\.?[0-9]+"
echo matches for expression 1
egrep  '^[-+]?[0-9]*\.?[0-9]+$' textfile.txt

# 2. Write a regexp that will match any string that starts with "cat" followed by at least one more character
echo matches for expression 2
egrep '^.$' textfile.txt

# 3. Write a regexp that will match any string that starts with ”hum” and ends with ”001” with any number of characters, including none, in between.  Hint: consider both ”.” and ”*”
echo matches for expression 3
egrep '^.$' textfile.txt

# 4. Write a regexp that will match any line that begins with "//"
echo matches for expression 4
egrep '^.$' textfile.txt

# 5. Write a regexpr that will match any line that begins with "/*" and ends with "*/"
echo matches for expression 5
egrep '^.$' textfile.txt

# 6. Write a regexpr that matches any line that represents a 32 bit hexadecimal number.
#    Starts with 0X, followed by 8 hexidecimal digits (0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F)
echo matches for expression 6
egrep '^.$' textfile.txt

# 7. Write a regexpr that will match any line that begins with two characters, followed by 1 digit, followed by 1 character, followed by 3 digits.  The last 3 digits represent the day of the year.  From 001 to 0365
echo matches for expression 7
egrep '^.$' textfile.txt

# 8. Write a regexpr that will match any line that consists of a series of characters (at least one) and ends with ".java".  No digits allowed.
echo matches for expression 8
egrep '^.$' textfile.txt

# 9. Write a regexpr that will matches a postfix increment or decrement statement.  Examples:  i++, i--, count++, count--, _val++, -val--
echo matches for expression 9
egrep '^.$' textfile.txt

#  10. Write a regexp that will match the rules for a password that requires at least 8 characters, followed by at least 2 digits followed by at least 2 punctuation marks (Can be written '[[:punct:]])'.
echo matches for expression 10
egrep '^.$' textfile.txt

# 11.  Write an expression that repeats the same three characters/digits four times in a row.  Examples:  lollollollol  yumyumyumyum 123123123123

echo matches for expression 11
egrep '^.$' textfile.txt


```

[RegEx101.com](https://regex101.com/) is a great site to practice.  Copy the output file shown below into their Test String Window and begin writing each expression.

 **Correct Output**
 
```bash
matches any real number
123.32
223.33
-32.3
+22.3
.3
123123123123
matches for expression 1
-32.3
+22.3
matches for expression 2
catt
cat2
catch
matches for expression 3
humbug001
matches for expression 4
//
// Comment
matches for expression 5
/* Multi Line Comment */
/* Flawed Multi Line Comment but still ok /* */
matches for expression 6
0X00ABCD00
0X00FF0000
matches for expression 7
ab1c234
mp1d034
matches for expression 8
a.java
filename.java
matches for expression 9
a++
count++
a--
count--
matches for expression 10
validpassword12!!
validpasswordle43&#
matches for expression 11
yumyumyumyum
123123123123
```